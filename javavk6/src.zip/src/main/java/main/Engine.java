package main;

public class Engine {
    public String name;
    public int power;

    public Engine(String name, int power) {
        this.name = name;
        this.power = power;
    }

}